
/**
 * BALLY FLOW API CONFIGURATION
 *
 * Physical Android phone:
 * The phone connects to the FastAPI backend
 * through the PC's local network IP address.
 *
 * FastAPI:
 * http://192.168.1.136:8000
 *
 * IMPORTANT:
 * Do NOT use 127.0.0.1 in the Android app.
 * On Android, 127.0.0.1 refers to the phone itself.
 */

export const API_BASE_URL = 'http://192.168.1.136:8000';

export const API_TIMEOUT_MS = 15000;

